#
#   tkmacpkg.rb - load tk/macpkg.rb
#
require 'tk/macpkg'
