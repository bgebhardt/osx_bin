#
#   tkvirtevent.rb - load tk/virtevent.rb
#
require 'tk/virtevent'
