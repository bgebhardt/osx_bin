#!/usr/bin/env python
# encoding: utf-8
"""
${TM_NEW_FILE_BASENAME}.py

Created by ${TM_FULLNAME} on ${TM_DATE}.
Copyright (c) ${TM_YEAR} ${TM_ORGANIZATION_NAME}. All rights reserved.
"""

import sys
import os
import unittest


class ${TM_NEW_FILE_BASENAME}:
	def __init__(self):
		pass


class ${TM_NEW_FILE_BASENAME}Tests(unittest.TestCase):
	def setUp(self):
		pass


if __name__ == '__main__':
	unittest.main()