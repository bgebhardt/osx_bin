#import <CoreFoundation/CoreFoundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <MacTypes.h>
#import <stdio.h>
#import <stdint.h>
#import <math.h>
#import <pthread.h>
#import <dispatch/dispatch.h>
#import <unistd.h>
#import <fcntl.h>

int main (int argc, char const* argv[])
{
	return 0;
}
